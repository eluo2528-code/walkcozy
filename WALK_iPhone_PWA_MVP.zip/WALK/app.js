const $=id=>document.getElementById(id);
const screens=["home","walk","finish","journal","settings"];
function show(id){screens.forEach(s=>$(s).style.display=s===id?"flex":"none");}
const toast=t=>{const el=$("toast");el.textContent=t;el.classList.add("show");setTimeout(()=>el.classList.remove("show"),2600)};
let home=JSON.parse(localStorage.getItem("walk_home")||"null");
let target=Number(localStorage.getItem("walk_target")||2);
$("targetKm").value=target;
let watch=null, paused=false, current=null, routePoints=[], walked=0, lastPos=null, photoData=null, heading=0;
const rad=x=>x*Math.PI/180, deg=x=>x*180/Math.PI;
function bearing(a,b){let p1=rad(a.lat),p2=rad(b.lat),dl=rad(b.lon-a.lon);let y=Math.sin(dl)*Math.cos(p2),x=Math.cos(p1)*Math.sin(p2)-Math.sin(p1)*Math.cos(p2)*Math.cos(dl);return (deg(Math.atan2(y,x))+360)%360}
function hav(a,b){let R=6371000,p1=rad(a.lat),p2=rad(b.lat),dp=p2-p1,dl=rad(b.lon-a.lon);let x=Math.sin(dp/2)**2+Math.cos(p1)*Math.cos(p2)*Math.sin(dl/2)**2;return 2*R*Math.asin(Math.sqrt(x))}
function pos(){return new Promise((resolve,reject)=>navigator.geolocation.getCurrentPosition(p=>resolve({lat:p.coords.latitude,lon:p.coords.longitude}),reject,{enableHighAccuracy:true,timeout:15000,maximumAge:5000}))}
function destination(p,meters,angle){let d=meters/6371000,t=rad(angle),lat1=rad(p.lat),lon1=rad(p.lon);let lat2=Math.asin(Math.sin(lat1)*Math.cos(d)+Math.cos(lat1)*Math.sin(d)*Math.cos(t));let lon2=lon1+Math.atan2(Math.sin(t)*Math.sin(d)*Math.cos(lat1),Math.cos(d)-Math.sin(lat1)*Math.sin(lat2));return {lat:deg(lat2),lon:deg(lon2)}}
async function getRoute(start,end){
  const body={locations:[{lat:start.lat,lon:start.lon},{lat:end.lat,lon:end.lon},{lat:start.lat,lon:start.lon}], costing:"pedestrian",units:"kilometers"};
  const r=await fetch("https://valhalla1.openstreetmap.de/route",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(body)});
  if(!r.ok)throw Error("route");const j=await r.json();
  // Decode Valhalla polyline6
  function decode(str){let i=0,lat=0,lon=0,out=[];while(i<str.length){let b,s=0,res=0;do{b=str.charCodeAt(i++)-63;res|=(b&31)<<s;s+=5}while(b>=32);lat+=(res&1)?~(res>>1):(res>>1);s=0;res=0;do{b=str.charCodeAt(i++)-63;res|=(b&31)<<s;s+=5}while(b>=32);lon+=(res&1)?~(res>>1):(res>>1);out.push({lat:lat/1e6,lon:lon/1e6})}return out}
  const shape=j.trip.legs.map(l=>decode(l.shape)).flat();return {points:shape,km:j.trip.summary.length};
}
async function buildRoute(){
  if(!home)throw Error("请先设置家的位置");
  $("walkHint").textContent="正在为你寻找一条安静的路……";
  // Random candidate bearings; prefer a route close to requested distance.
  let best=null;
  for(let i=0;i<5;i++){
    const waypoint=destination(home,Math.max(350,target*260),Math.random()*360);
    try{const r=await getRoute(home,waypoint);let score=Math.abs(r.km-target)+Math.random()*.12;
      if(!best||score<best.score)best={...r,score};
    }catch(e){}
  }
  if(!best)throw Error("暂时无法规划路线，请检查网络后重试");
  routePoints=best.points;current={km:best.km,started:Date.now(),points:[home],distance:0};
  walked=0;lastPos=null;
  $("distance").textContent=best.km.toFixed(1);
  $("walkHint").textContent="慢慢走，不着急。";
}
$("start").onclick=async()=>{
  if(!navigator.geolocation){toast("这台设备暂不支持定位");return}
  try{
    if(!home){toast("先设置家的位置");show("settings");return}
    show("walk");await buildRoute();
    watch=navigator.geolocation.watchPosition(p=>{
      if(paused)return;const now={lat:p.coords.latitude,lon:p.coords.longitude};
      if(lastPos){const d=hav(lastPos,now);if(d<80){walked+=d/1000;current.distance=walked;current.points.push(now)}}
      lastPos=now;
      let nearest=0,nd=Infinity;routePoints.forEach((pt,i)=>{let d=hav(now,pt);if(d<nd){nd=d;nearest=i}});
      const next=routePoints[Math.min(nearest+3,routePoints.length-1)];
      const b=bearing(now,next);$("arrow").style.transform=`rotate(${b}deg)`;
      const remaining=Math.max(0,current.km-walked);
      $("distance").textContent=remaining.toFixed(1);
      if(nd>150)$("walkHint").textContent="按自己的节奏，慢慢来。";
    },e=>toast("定位暂时不可用，请检查定位权限"),{enableHighAccuracy:true,maximumAge:3000,timeout:20000});
  }catch(e){show("home");toast(e.message||"路线暂时不可用")}
};
$("pauseBtn").onclick=()=>{paused=!paused;$("pauseBtn").textContent=paused?"继续":"暂停";$("walkHint").textContent=paused?"休息一下也很好。":"慢慢走，不着急。"};
$("endBtn").onclick=()=>{if(watch!==null)navigator.geolocation.clearWatch(watch);watch=null;show("finish");$("finishStats").textContent=`今天走过约 ${walked.toFixed(2)} 公里。`};
$("photoInput").onchange=e=>{const f=e.target.files[0];if(!f)return;const reader=new FileReader();reader.onload=()=>{photoData=reader.result;$("photoBox").innerHTML=`<img src="${photoData}" alt="今天的照片">`};reader.readAsDataURL(f)};
function getRecords(){return JSON.parse(localStorage.getItem("walk_records")||"[]")}
$("saveBtn").onclick=()=>{const rec={date:new Date().toISOString(),km:walked.toFixed(2),memo:$("memo").value,photo:photoData};let a=getRecords();a.unshift(rec);localStorage.setItem("walk_records",JSON.stringify(a));resetFinish();show("home");toast("今天的旅程，已经收藏。")};
function resetFinish(){photoData=null;$("photoInput").value="";$("photoBox").textContent="拍一张照片，留住此刻";$("memo").value=""}
$("discardBtn").onclick=()=>{resetFinish();show("home")};
$("journalLink").onclick=()=>{renderJournal();show("journal")};
$("settingsLink").onclick=()=>show("settings");
document.querySelectorAll(".backHome").forEach(b=>b.onclick=()=>show("home"));
$("setHomeBtn").onclick=async()=>{try{const p=await pos();home=p;localStorage.setItem("walk_home",JSON.stringify(home));target=Number($("targetKm").value)||2;localStorage.setItem("walk_target",target);toast("家的位置已保存。");show("home")}catch(e){toast("无法获取位置，请允许浏览器使用定位")}};
$("targetKm").onchange=()=>{target=Math.min(5,Math.max(.8,Number($("targetKm").value)||2));$("targetKm").value=target;localStorage.setItem("walk_target",target)};
function renderJournal(){const box=$("entries"),a=getRecords();box.innerHTML="";if(!a.length){box.innerHTML='<div class="sub">这里还很安静。<br>等第一次散步回来，再留下一张照片。</div>';return}a.forEach(r=>{const d=new Date(r.date);const el=document.createElement("div");el.className="entry";const img=document.createElement("img");img.className="thumb";img.src=r.photo||"";const content=document.createElement("div");const date=document.createElement("div");date.className="entrydate";date.textContent=d.toLocaleDateString("zh-CN",{year:"numeric",month:"long",day:"numeric"});const meta=document.createElement("div");meta.className="entrymeta";meta.textContent=`${r.km} 公里`;const memo=document.createElement("div");memo.className="entrymeta";memo.style.marginTop="8px";memo.textContent=r.memo||"";content.append(date,meta,memo);el.append(img,content);box.append(el)})}
if("serviceWorker"in navigator)window.addEventListener("load",()=>navigator.serviceWorker.register("./sw.js").catch(()=>{}));
